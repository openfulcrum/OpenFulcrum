<!-- shins; content for the head element from source/includes/_head.md -->
<meta name="theme-color" content="#F3F7F9">
