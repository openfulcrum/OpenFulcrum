---
title: Master/Include Sample v1.0.0
language_tabs:
  - javascript--nodejs: Node.JS
  - javascript: JavaScript
  - python: Python
  - ruby: Ruby
  - java: Java
  - go: Go
toc_footers:
  - '<a href="https://mermade.github.io/shins/index.html">See OpenAPI example</a>'
includes: []
search: true
highlight_theme: darkula
---

# Master content

## Included content

include::include.md[]

## Included content 2

!INCLUDE include.md

